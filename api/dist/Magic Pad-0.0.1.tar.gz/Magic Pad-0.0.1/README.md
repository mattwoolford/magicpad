# Magic Pad
Copyright © Matt Woolford - All Rights Reserved
 * Unauthorised copying of this directory or any of the files contained within, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Matt Woolford <matt@mattwoolford.co.uk>, March 2022

Magic Pad is a tool designed for use in a restaurant environment that can help eradicate bottlenecks, reduce common service errors and substitute pen and paper with a more informative alternative.